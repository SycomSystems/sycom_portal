#!/bin/bash
# ═══════════════════════════════════════════════════════════════
#  SYCOM PORTAL — STOCK MODULE REWORK DEPLOYMENT
#  Run on VPS: cd /opt/sycom-portal && bash deploy-sklad.sh
# ═══════════════════════════════════════════════════════════════

set -e
cd /opt/sycom-portal

echo "📦 Step 1: Copy new files..."

# ── 1. Replace schema.prisma ──────────────────────────────────
# Copy the new schema.prisma from the rework package

# ── 2. Create API directories ─────────────────────────────────
mkdir -p src/app/api/stock/supplier-prices
mkdir -p src/app/api/stock/suppliers
mkdir -p src/app/api/stock/items/\[id\]
mkdir -p src/app/\(admin\)/admin/sklad/items/\[id\]

echo "✅ Directories created"

# ── 3. Run DB migration ──────────────────────────────────────
echo "📦 Step 2: Database migration..."
npx prisma generate
npx prisma db push
echo "✅ Database updated"

# ── 4. Build ─────────────────────────────────────────────────
echo "🔨 Step 3: Building..."
rm -rf .next
npm run build

# ── 5. Restart ───────────────────────────────────────────────
echo "🚀 Step 4: Restarting..."
pm2 restart sycom-portal

echo ""
echo "✅ Stock rework deployed successfully!"
echo ""
echo "New features:"
echo "  ✓ Goods cards (Karty tovaru) with full info"
echo "  ✓ Multi-supplier price list per item"
echo "  ✓ Weighted average purchase price tracking"
echo "  ✓ Invoice number field on movements"
echo "  ✓ Margin calculation on sales"
echo "  ✓ Stock value summary"
echo "  ✓ Preferred supplier marking"
echo "  ✓ Supplier lead time & min order qty"
echo "  ✓ Item detail page with movement history"
